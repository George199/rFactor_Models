gMotor 2.0 MAS Utility

The gMotor 2.0 MAS utility is used to create MAS archive files for use in gMotor 2.0 applications only.  A MAS file is very similar to other well-known types of compressed archive files, and contains additional information specific to a gMotor application. 


All information, documentation, or software ("Information") is being provided "AS IS". Image Space Incorporated does not and cannot warrant this Information (including any fixes and updates) or the performance or results obtained by using it. Image Space Incorporated makes no warranties of any kind, either expressed or implied, including but not limited to, non-infringement of third party rights, merchantability, or fitness for a particular purpose. To the extent you use or implement this Information, you do so at your own risk. In no event will ISI be liable to you or others for any damages arising from your use or your inability to use any of the information, documentation, or software.  Commercial exploitation is prohibited.  Image Space Incorporated may terminate, change, or suspend any aspect of this Site and the contents provided at any time. Please visit http://www.rFactor.net/legal.html for additional or updated information.

Copyright �2005 Image Space Incorporated
